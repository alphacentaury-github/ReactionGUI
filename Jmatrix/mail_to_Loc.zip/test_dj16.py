# -*- coding: utf-8 -*-
"""
test two-body problems in various methods

@author: Y.-H. song
"""
import sys, os
sys.path.append(os.pardir)

import numpy as np
import scipy
import scipy.linalg as la
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages

from scipy.special import hyp1f1
from scipy.special import gamma
from scipy.special import assoc_laguerre

from special_zj_py import hyp1f1_zj 

#hbarc = my_constants.hbarc
hbarc = 197.32698059082031
#mu = 0.5*my_constants.mN # MeV
mu= 931.494/2 

from DJ16py import *

#========HO basis calculation=================================================
def kin_me(n,l,npp,lpp,J,S,hw=25.0):
    """
    compute < n,l| p^2/(2 mu) | np, lp>
    in H.O. basis
    with given hw = hbar*Omega
    
    Here, angular momentum conservation is imposed. 
    """
    # in unit of MeV
    out = 0.0
    if ((n,l)==(npp,lpp)):
        out = (2*n+l+1.5)
    if (n==npp+1 and l==lpp):
        out = np.sqrt((npp+1)*(npp+l+1.5))
    if (npp==n+1 and l==lpp):
        out = np.sqrt((n+1)*(n+l+1.5))
    return out/2*hw

def pot_me(n,l,npp,lpp,J,S,hw=25.0):
    """
    return
    < nl|V| np lp>
    """
    return dj16_me(n,l,npp,lpp,J,S)

def construct_Hmat_single_HO(L,J,S,npot=20,nmax=30):
    """
     H_{i,j} 
     i,j = 0...npot : V are non-zero 
     i,j = npot+1... nmax : V are zero      
    """
    # uncoupled channel Hamiltonian
    Kmat = np.zeros((nmax+1,nmax+1))
    Vmat = np.zeros((nmax+1,nmax+1))
    for n in range(nmax+1):
        for m in range(nmax+1):
            Kmat[n,m] = kin_me(n,L,m,L,J,S)
    for n in range(npot+1):
        for m in range(npot+1):
            Vmat[n,m] = pot_me(n,L,m,L,J,S)
    Hmat = Kmat + Vmat
    return Hmat, Kmat, Vmat
    
def construct_Hmat_couple_HO(J=1,npot=20,nmax=30):
    """
     L= J-1 and L= J+1 coupled channel Hamiltonian
     
     H_{i,j} 
     i,j = 0...npot : V are non-zero 
     i,j = npot+1... nmax : V are zero      
     i,j = nmax+1... nmax+npot+1 : V are non-zero 
     i,j = nmax+npot+2.... 2*(nmax) : V are zero 
     
     The matrix element is in unit of MeV !! 
    """
    S = 1
    # uncoupled channel Hamiltonian
    Kmat = np.zeros((2*(nmax+1),2*(nmax+1)) )
    Vmat = np.zeros((2*(nmax+1),2*(nmax+1)) )
    #----kinetic term 
    for n in range(nmax+1):
        for m in range(nmax+1):
            Kmat[n,m] = kin_me(n,J-1,m,J-1,J,S)
            Kmat[n+nmax+1,m+nmax+1] = kin_me(n,J+1,m,J+1,J,S)
    #----potential term         
    for n in range(npot+1):
        for m in range(npot+1):
            Vmat[n,m] = pot_me(n,J-1,m,J-1,J,S)
            Vmat[n+nmax+1,m] = pot_me(n,J+1,m,J-1,J,S)
            Vmat[n,m+nmax+1] = pot_me(n,J-1,m,J+1,J,S)
            Vmat[n+nmax+1,m+nmax+1] = pot_me(n,J+1,m,J+1,J,S)
    Hmat = Kmat + Vmat
    return Hmat, Kmat, Vmat

def ln_dble_fact(n):
    """
     log double factorial
     log(n!!)
    """
    res = 0.0
    if (n<2):
        return res
    for i in range(n,1,-2):
        res = res + np.log(i*1.0)
    return res


def cn_array_recursion(q,L,nmax):
    """
    compute c_{nl} of H.O. basis
    using recursion relation.
    c_0.... c_{nmax} 
    """
    from scipy.special import hyp1f1
    from scipy.special import gamma
    from scipy.special import gammaln
    #from scipy.special import assoc_laguerre

    q2=q*q
    sqrtsqrtpi = np.sqrt(np.sqrt(np.pi))
    cnl=np.zeros(nmax+1)
    #--this expression does not use gamma function with half integer.  
    for n in [0,1]: 
        factor = 0.5*( ln_dble_fact(n)- ln_dble_fact(2*n+2*L+1) - q2
                      + (n-L+1.0)*np.log(2.0)) -L*np.log(q)
        factor = factor + ln_dble_fact(2*L-1)
        #mphi = hyp1f1(-n-L-0.5,-L+0.5 , q2)
        mphi = hyp1f1_zj(-n-L-0.5,-L+0.5 , q2)
        cnl[n] = (-1)**n*mphi/sqrtsqrtpi*np.exp(factor)
    if (nmax==1):
        return cnl

    for n in range(1,nmax):
        Tnn = 2*n+L+1.5
        Tnn1 = np.sqrt((n+1.0)*(n+L+1.5))
        Tnn_1 = np.sqrt(n*1.0*(n+L+0.5))
        Tnn = (q2-Tnn)/Tnn1
        Tnn_1 = Tnn_1/Tnn1 
        cnl[n+1] = Tnn* cnl[n]
        cnl[n+1] = cnl[n+1]- Tnn_1*cnl[n-1]
    return cnl


def sc_coeffs(q,L,nmax):
    """
    computes s_nl, c_nl
    according to the Yamani's definition

    Note : b factors are extracted...
           s_n and c_n are dimensionless!!!
    
    s_0... s_nmax 
    """
    nu = L+0.5
    fac_sn = np.sqrt(np.pi/2)*np.exp(-q**2/2)*q**(L+1)
    fac_cn = gamma(nu)/np.sqrt(2*np.pi)*np.exp(-q**2/2)*q**(-L)
    snl=[]; cnl =[]
    for n in range(nmax+1):
        an = np.sqrt(2*gamma(n+1)/gamma(n+nu+1))
        Lval = assoc_laguerre(q**2, n,nu)
        #Fval = hyp1f1(-n-nu,1-nu,q**2)
        Fval = hyp1f1_zj(-n-nu,1-nu,q**2)
        snl_val = (-1)**n*fac_sn*an*Lval
        cnl_val = (-1)**n*fac_cn*an*Fval
        snl.append(snl_val)
        cnl.append(cnl_val)
    snl = np.array(snl)
    cnl = np.array(cnl)
    return snl, cnl
    
def test_Jmat_coupled(emax =100.0,npot=20,nmax= 50,hw=25.0, phase_opt=2,
                      J=1,S=1):
    """
    computes phase shifts for Daejeon16 potential 
    by using J-matrix method.
    
    potential up to 0...npot are non-zero 
    full model space is up to 0....nmax 
    """    
    Hmat,Kmat,Vmat = construct_Hmat_couple_HO(J,npot=npot,nmax=nmax)
    ecm,vv= scipy.linalg.eigh(Hmat) # vv or u_n is dimension-less
    b_fm = hbarc/np.sqrt(mu*hw)
    print('b.e.= ',ecm[ecm<0], 'b(fm)=',b_fm )
    enlist= []
    phase = []
    
    if phase_opt==2:
        enlist= np.linspace(0.01,emax,20)
        for i,ee in enumerate(enlist):
            q = np.sqrt(2*ee/hw); #dimensionless
            #----construct incoming/outgoing 
            sn_low,cn_low = sc_coeffs(q,J-1,nmax+1)
            cn_low = cn_array_recursion(q,J-1,nmax+1) #replace 
            sn_hig, cn_hig = sc_coeffs(q,J+1,nmax+1)
            cn_hig = cn_array_recursion(q,J+1,nmax+1) #replace 
            
            hplus_M= np.array([[cn_low[nmax]+1j*sn_low[nmax],0],
                                [0,cn_hig[nmax]+1j*sn_hig[nmax]]]) 
            
            hmnus_M= np.array([[cn_low[nmax]-1j*sn_low[nmax],0],
                                [0,cn_hig[nmax]-1j*sn_hig[nmax]]]) 
            
            hplus_M1= np.array([[cn_low[nmax+1]+1j*sn_low[nmax+1],0],
                                [0,cn_hig[nmax+1]+1j*sn_hig[nmax+1]]]) 
            
            hmnus_M1=  np.array([[cn_low[nmax+1]-1j*sn_low[nmax+1],0],
                                 [0,cn_hig[nmax+1]-1j*sn_hig[nmax+1]]]) 
            #----construct g^{ab}_{M,M} 
            eps = 0.0 # optional 
            gmat = (ee+1j*eps)*np.eye(2*nmax+2)-Hmat  
            gmat = np.linalg.inv(gmat)
            gmat_mm = np.zeros((2,2))*1j
            gmat_mm[0,0] = gmat[nmax,nmax]
            gmat_mm[0,1] = gmat[nmax,2*nmax+1]
            gmat_mm[1,0] = gmat[2*nmax+1,nmax]
            gmat_mm[1,1] = gmat[2*nmax+1,2*nmax+1]
            
            #----construct J^{ab}_{M,M+1} 
            tnn_low  = kin_me(nmax,J-1,nmax+1,J-1,J,S,hw)
            tnn_high = kin_me(nmax,J+1,nmax+1,J+1,J,S,hw)
            tnn_mat = np.array([[tnn_low,0],[0,tnn_high]])
            
            #----solve S-matrix 
            top_mat = hmnus_M - np.matmul(gmat_mm, np.matmul(tnn_mat,hmnus_M1))
            bot_mat = hplus_M - np.matmul(gmat_mm, np.matmul(tnn_mat,hplus_M1))             
            Smat = scipy.linalg.solve(bot_mat,top_mat)
            
            #---get phase shifts               
            phs_diff = np.log(Smat[0,0]/Smat[1,1])/(2*1j)
            eps = np.arctan(Smat[0,1]/Smat[1,1]/1j/np.exp(1j*(phs_diff)))/2.
            phs_sum = np.log(Smat[0,1]/(1j*np.sin(2*eps)))/(1j)
            phs_low = (phs_sum+phs_diff)/2.
            phs_high = (phs_sum-phs_diff)/2.
            
            phase.append([np.real(phs_low),np.real(phs_high),np.real(eps)] )
    else:
        raise ValueError('Not available')        
    return np.array(enlist), np.array(phase)

#==============================================================================
if __name__ == '__main__':
    #---DJ16 in HO basis 
    en_list3,phase_list3 = test_Jmat_coupled(
         emax =200.0,npot=20,nmax= 50,hw=25.0, phase_opt=2) #3S1-3D1 
    phs_3S1_Jmat = phase_list3[:,0]
    phs_3S1_Jmat[phs_3S1_Jmat<0] = phs_3S1_Jmat[phs_3S1_Jmat<0]+np.pi
    phs_3D1_Jmat = phase_list3[:,1]
    phs_E1_Jmat = phase_list3[:,2]        
    #-------plot 3S1-3D1------------- 
    expdat = np.loadtxt('np_J1.dat')
    with PdfPages('phase3S1.pdf') as pdf:       
        plt.figure()
        plt.plot(en_list3,phs_3S1_Jmat,'.',label='dj16_full 3S1 Jmat'  )
        plt.plot(expdat[:,0]/2.,expdat[:,1]*np.pi/180,'--',label='PWA 3S1')        
        plt.plot(en_list3,phs_3D1_Jmat,'.',label='dj16_full 3D1 Jmat'  )
        plt.plot(expdat[:,0]/2.,expdat[:,2]*np.pi/180,'--',label='PWA 3D1')        
        plt.plot(en_list3,np.abs(phs_E1_Jmat),'.',label='dj16_full E1 Jmat'  )
        plt.plot(expdat[:,0]/2.,expdat[:,3]*np.pi/180,'--',label='PWA E1')
        plt.legend()
        plt.xlim([0,200])
        plt.xlabel('E_cm [MeV]');plt.ylabel('radian')
        pdf.savefig() 
        plt.close() 